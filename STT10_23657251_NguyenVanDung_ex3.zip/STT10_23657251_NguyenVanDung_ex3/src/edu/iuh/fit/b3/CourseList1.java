package edu.iuh.fit.b3;

public class CourseList1 {
    private Course1[] courses;
    private int count = 0;
    public CourseList1(int n) {
        if (n<=0)
            throw new IllegalArgumentException("Length of the array must be greater than 0");
        courses = new Course1[n];
    }

    public boolean addCourse(Course1 course) {
        //check if course is null
        if (course==null)
            return false;
        //check if course already exits
        if (isExits(course))
            return false;
        //check if array is full
        if (count==courses.length)
            return false;
        courses[count++] = course;
        return true;
    }

    private boolean isExits(Course1 course) {
        for (int i=0; i<count; i++){
            if (courses[i].getId().equalsIgnoreCase(course.getId()))
                return true;
        }
        return false;
    }

    public Course1[] getCourses() {
        return courses;
    }


}
