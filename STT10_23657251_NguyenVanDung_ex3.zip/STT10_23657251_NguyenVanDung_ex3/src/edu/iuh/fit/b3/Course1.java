package edu.iuh.fit.b3;

public class Course1 {
    private String id;
    private String title;
    private int credit;
    private String department;

    public Course1(String id, int credit, String title, String department) {
        this.id = id;
        this.credit = credit;
        this.title = title;
        this.department = department;
    }

    public Course1(){
        this("", 0, "", "");

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        if (id == null || id.trim().length() < 3)
            throw new IllegalArgumentException("ID must have at least 3 characters");
        int len = id.length();
        for (int i =0; i < len; i++) {
            char ch = id.charAt(i);
            if(!Character.isLetterOrDigit(ch))
                throw new IllegalArgumentException("ID must contain only letters or digits");
        }
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getCredit() {
        return credit;
    }

    public void setCredit(int credit) {
        this.credit = credit;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    @Override
    public String toString() {
        return String.format("%-10s%-30s%10d%-20s", id, title, credit, department);
    }

}
