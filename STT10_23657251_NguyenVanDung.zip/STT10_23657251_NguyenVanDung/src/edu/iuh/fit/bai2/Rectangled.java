
/*
 * @ (#) Rectangled.java       1.0  26/08/2024
 *
 * Copyringht (c) 2024 IUH. All rights reserred
 */
package edu.iuh.fit.bai2;

/*
 *@description:
 *@author: Dung Nguyen Van
 *@date: 26/08/2024
 *@version: 1.0
 */
public class Rectangled {
    // Properties
    private double length;
    private double width;

    // Constructors
    public Rectangled() {
        this(0.0, 0.0);
    }

    public Rectangled(double length, double width) {
        if (length < 0 || width < 0) throw new IllegalArgumentException("Length and width must be greater than 0");
        this.length = length;
        this.width = width;
    }

    // Setters/Getters

    /**
     * Set the length of the rectangle
     * @param length The length of the rectangle
     * @throws IllegalArgumentException if length less than 0
     */
    public void setLength(double length) {
        if (length < 0.0) throw new IllegalArgumentException("Length must be greater than 0");
        this.length = length;
    }

    public void setWidth(double width) {
        if (width < 0.0) throw new IllegalArgumentException("Width must be greater than 0");
        this.width = width;
    }

    public double getLength() {
        return this.length;
    }

    public double getWidth() {
        return width;
    }
}
