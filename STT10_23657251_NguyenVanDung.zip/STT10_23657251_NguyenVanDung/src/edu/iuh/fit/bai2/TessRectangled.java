
/*
 * @ (#) TessRectangled.java       1.0  26/08/2024
 *
 * Copyringht (c) 2024 IUH. All rights reserred
 */
package edu.iuh.fit.bai2;

/*
 *@description:
 *@author: Dung Nguyen Van
 *@date: 26/08/2024
 *@version: 1.0
 */
public class TessRectangled {
    public static void main(String[] args) {
        Rectangled r = new Rectangled() ;
        r.setWidth (3.0);
        r.setLength (1.0);


    }
}
