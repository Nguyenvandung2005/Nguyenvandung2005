package edu.iuh.fit.b3;

public class TestCourse1 {
    public static void main(String[] args) {
//        Course c = new Course();
//        c.setId("");
        CourseList1 courseList = new CourseList1(10);
        initData(courseList);
        System.out.printf("%-10s%-10s  %30s%20s\n", "id", "title", "credit", "department");
        Course1[] temp = courseList.getCourses();
        for (Course1 course : temp) {
            if (course != null) {
                System.out.println(course);
            }
        }
    }
    private static void initData(CourseList1 courseList) {
        Course1 c1 = new Course1("CS101", 3 , "Java Programing", "CS");
        Course1 c2 = new Course1("IS201", 3 , "Database Programing", "IS");
        Course1 c3 = new Course1("SE301", 3 , "C# Programing", "SE");
        courseList.addCourse(c1);
        courseList.addCourse(c2);
        courseList.addCourse(c3);
    }

}
